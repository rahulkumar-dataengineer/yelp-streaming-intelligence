"""Shared infrastructure for portfolio data engineering projects."""

__version__ = "0.2.1"
