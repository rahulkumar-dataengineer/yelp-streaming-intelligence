"""Hive Metastore utilities."""

try:
    from platform_commons.hive.metastore import init_metastore
except ImportError as exc:
    raise ImportError(
        "platform_commons.hive requires pyspark. "
        "Install with: pip install platform-commons[spark]"
    ) from exc

__all__ = ["init_metastore"]
