"""Metastore initialisation — creates databases and executes DDL statements.

Accepts DDL as parameters so projects provide their own table definitions.
"""

from pyspark.sql import SparkSession

from platform_commons.logger import Logger

log = Logger.get(__name__)


def init_metastore(
    spark: SparkSession,
    databases: list[str],
    tables: list[tuple[str, str]],
) -> None:
    """Creates databases and registers tables via DDL statements.

    Args:
        spark: Active SparkSession with Hive support.
        databases: List of database names to create.
        tables: List of (description, DDL statement) tuples.
               The DDL should be a ready-to-execute SQL string.
    """
    for db in databases:
        spark.sql(f"CREATE DATABASE IF NOT EXISTS {db}")
        log.info(f"Database ensured: {db}")

    for description, ddl in tables:
        spark.sql(ddl)
        log.info(f"Table ensured: {description}")

    log.info("Metastore initialisation complete.")
