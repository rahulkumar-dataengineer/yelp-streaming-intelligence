"""Kafka ecosystem utilities — producer, schema registry, Avro schema loading, signals."""

try:
    from platform_commons.kafka.producer import create_producer, produce_topic
    from platform_commons.kafka.schema_registry import (
        create_registry_client,
        enable_topic_validation,
        get_subjects,
        register_all,
        register_schema,
        set_compatibility,
    )
except ImportError as exc:
    raise ImportError(
        "platform_commons.kafka requires confluent-kafka. "
        "Install with: pip install platform-commons[kafka]"
    ) from exc

from platform_commons.kafka.schema_loader import load_avsc, load_all_avsc
from platform_commons.kafka.signals import get_running, register_signal_handlers

__all__ = [
    "create_producer",
    "produce_topic",
    "create_registry_client",
    "enable_topic_validation",
    "get_subjects",
    "register_all",
    "register_schema",
    "set_compatibility",
    "load_avsc",
    "load_all_avsc",
    "get_running",
    "register_signal_handlers",
]
