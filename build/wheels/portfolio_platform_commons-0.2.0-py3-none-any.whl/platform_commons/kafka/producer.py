"""Generic Kafka producer with Avro serialization via Confluent Schema Registry.

All functions accept explicit parameters — no settings imports.

Usage:
    from platform_commons.kafka.producer import create_producer, produce_topic

    producer = create_producer("localhost:9092", "http://localhost:8081", my_avro_schema)
    produce_topic(producer, "my_topic", records_generator(), key_field="event_id", entity_name="events")
"""

import json
from typing import Generator

from confluent_kafka import KafkaException, SerializingProducer
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.schema_registry.avro import AvroSerializer
from confluent_kafka.serialization import StringSerializer

from platform_commons.logger import Logger
from platform_commons.kafka.signals import get_running

log = Logger.get(__name__)

_POLL_INTERVAL: int = 1_000


def _delivery_report(err, msg) -> None:
    """Callback for Kafka delivery reports."""
    if err is not None:
        log.warning(f"Delivery failed for {msg.topic()}[{msg.partition()}]: {err}")


def create_producer(
    bootstrap_servers: str,
    schema_registry_url: str,
    avro_schema: dict,
) -> SerializingProducer:
    """Creates a SerializingProducer with AvroSerializer for values.

    Args:
        bootstrap_servers: Kafka bootstrap servers (e.g. "localhost:9092").
        schema_registry_url: Schema registry URL (e.g. "http://localhost:8081").
        avro_schema: Avro schema dict for value serialization.
    """
    registry_client = SchemaRegistryClient({"url": schema_registry_url})

    avro_serializer = AvroSerializer(
        schema_registry_client=registry_client,
        schema_str=json.dumps(avro_schema),
    )

    producer = SerializingProducer({
        "bootstrap.servers": bootstrap_servers,
        "key.serializer": StringSerializer("utf_8"),
        "value.serializer": avro_serializer,
    })

    log.info(f"SerializingProducer created -> {bootstrap_servers}")
    return producer


def produce_topic(
    producer: SerializingProducer,
    topic: str,
    records: Generator[dict, None, None],
    key_field: str,
    entity_name: str,
    progress_interval: int = 10_000,
) -> None:
    """Produces records to a Kafka topic with delivery reports and backpressure handling.

    Args:
        producer: A SerializingProducer instance.
        topic: Target Kafka topic name.
        records: Generator yielding dicts to produce.
        key_field: Field name in each record to use as the message key.
        entity_name: Label for logging (e.g. "businesses", "events").
        progress_interval: Log progress every N records.
    """
    sent = 0
    errors = 0
    log.info(f"[{entity_name}] Starting production -> topic '{topic}'")

    for record in records:
        if not get_running():
            log.info(f"[{entity_name}] Shutdown flag detected — stopping.")
            break

        try:
            producer.produce(
                topic=topic,
                key=record.get(key_field, ""),
                value=record,
                on_delivery=_delivery_report,
            )
            sent += 1

            if sent % _POLL_INTERVAL == 0:
                producer.poll(0)

            if sent % progress_interval == 0:
                log.info(f"[{entity_name}] Progress: {sent:,} records sent.")

        except KafkaException as exc:
            errors += 1
            log.warning(
                f"[{entity_name}] Failed to send record "
                f"({key_field}={record.get(key_field, '?')}): {exc}"
            )
        except BufferError:
            producer.poll(1)
            try:
                producer.produce(
                    topic=topic,
                    key=record.get(key_field, ""),
                    value=record,
                    on_delivery=_delivery_report,
                )
                sent += 1
            except Exception as exc:
                errors += 1
                log.warning(f"[{entity_name}] Retry failed: {exc}")

    log.info(f"[{entity_name}] Done — {sent:,} sent, {errors} errors.")
