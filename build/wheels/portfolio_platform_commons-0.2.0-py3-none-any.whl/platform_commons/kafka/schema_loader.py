"""Generic Avro schema loader — loads .avsc files from any package.

Usage:
    from platform_commons.kafka.schema_loader import load_avsc

    BUSINESS_SCHEMA = load_avsc("schemas", "yelp_business.avsc")
"""

import json
from importlib.resources import files
from typing import Any


def load_avsc(package_name: str, filename: str) -> dict[str, Any]:
    """Loads a single .avsc file from a package directory."""
    package = files(package_name)
    return json.loads((package / filename).read_text())


def load_all_avsc(package_name: str) -> dict[str, dict[str, Any]]:
    """Loads all .avsc files from a package directory.

    Returns dict mapping filename (without extension) to parsed schema dict.
    """
    package = files(package_name)
    schemas: dict[str, dict[str, Any]] = {}
    for resource in package.iterdir():
        if resource.name.endswith(".avsc"):
            name = resource.name.removesuffix(".avsc")
            schemas[name] = json.loads(resource.read_text())
    return schemas
