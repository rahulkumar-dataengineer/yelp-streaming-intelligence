"""Schema registry utilities — register Avro schemas, set compatibility,
enable server-side validation on Redpanda/Kafka topics.

All functions accept explicit parameters (no settings imports).
"""

import json

from confluent_kafka.admin import AdminClient, ConfigResource, ResourceType
from confluent_kafka.schema_registry import Schema, SchemaRegistryClient

from platform_commons.logger import Logger

log = Logger.get(__name__)


def create_registry_client(registry_url: str) -> SchemaRegistryClient:
    """Creates a SchemaRegistryClient for the given URL."""
    return SchemaRegistryClient({"url": registry_url})


def register_schema(
    client: SchemaRegistryClient,
    subject: str,
    avro_schema: dict,
) -> int:
    """Registers an Avro schema under the given subject. Returns the schema ID."""
    schema = Schema(json.dumps(avro_schema), "AVRO")
    schema_id = client.register_schema(subject, schema)
    log.info(f"Schema registered: {subject} -> id={schema_id}")
    return schema_id


def set_compatibility(
    client: SchemaRegistryClient,
    subject: str,
    level: str = "BACKWARD",
) -> None:
    """Sets the compatibility level for a subject."""
    client.set_compatibility(subject_name=subject, level=level)
    log.info(f"Compatibility set: {subject} -> {level}")


def enable_topic_validation(
    bootstrap_servers: str,
    topic: str,
) -> None:
    """Enables server-side schema validation on a Redpanda topic."""
    admin = AdminClient({"bootstrap.servers": bootstrap_servers})

    resource = ConfigResource(
        ResourceType.TOPIC,
        topic,
        set_config={
            "redpanda.value.schema.id.validation": "true",
        },
    )

    futures = admin.alter_configs([resource])
    for res, future in futures.items():
        future.result()
        log.info(f"Topic validation enabled: {res}")


def register_all(
    registry_url: str,
    bootstrap_servers: str,
    subject_schemas: dict[str, dict],
    compatibility: str = "BACKWARD",
) -> dict[str, int]:
    """Registers multiple schemas, sets compatibility, enables topic validation.

    Args:
        registry_url: Schema registry URL.
        bootstrap_servers: Kafka bootstrap servers.
        subject_schemas: Mapping of subject name (e.g. "my_topic-value") to Avro schema dict.
        compatibility: Compatibility level to set on each subject.

    Returns:
        Dict mapping subject name to registered schema ID.
    """
    client = create_registry_client(registry_url)

    registered: dict[str, int] = {}
    topics: set[str] = set()

    for subject, avro_schema in subject_schemas.items():
        registered[subject] = register_schema(client, subject, avro_schema)
        set_compatibility(client, subject, compatibility)

        # Extract topic name from subject (strip "-value" or "-key" suffix)
        if subject.endswith("-value"):
            topics.add(subject.removesuffix("-value"))
        elif subject.endswith("-key"):
            topics.add(subject.removesuffix("-key"))

    for topic in topics:
        enable_topic_validation(bootstrap_servers, topic)

    log.info(f"All schemas registered with {compatibility} compatibility: {registered}")
    return registered


def get_subjects(registry_url: str) -> list[str]:
    """Lists all registered subjects in the schema registry."""
    client = create_registry_client(registry_url)
    return client.get_subjects()
