"""Graceful shutdown signal handling for long-running processes."""

import signal

from platform_commons.logger import Logger

log = Logger.get(__name__)

_running: bool = True


def get_running() -> bool:
    """Returns False after a shutdown signal has been received."""
    return _running


def _handle_shutdown(signum: int, frame) -> None:
    global _running
    _running = False
    log.info(f"Shutdown signal received (signal {signum}). Finishing current batch...")


def register_signal_handlers() -> None:
    """Registers SIGINT and SIGTERM handlers for graceful shutdown."""
    signal.signal(signal.SIGINT, _handle_shutdown)
    signal.signal(signal.SIGTERM, _handle_shutdown)
    log.debug("Signal handlers registered (SIGINT, SIGTERM).")
