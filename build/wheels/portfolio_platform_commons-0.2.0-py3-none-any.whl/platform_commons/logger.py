"""Centralised logging factory with console and file handlers.

Usage:
    # At application startup (once):
    Logger.configure("my_app")

    # In any module:
    from platform_commons.utils.logger import Logger
    log = Logger.get(__name__)
    log.info("hello")
"""

import logging
import sys
from pathlib import Path


_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)-25s | %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"


class Logger:
    _app_root: str = "platform"
    _configured: bool = False

    @classmethod
    def configure(
        cls,
        app_root: str,
        log_file: str = "logs/app.log",
    ) -> None:
        """Configures handlers once. Call at application startup."""
        cls._app_root = app_root

        if cls._configured:
            return
        cls._configured = True

        app_logger = logging.getLogger(cls._app_root)

        if app_logger.handlers:
            return

        logging.getLogger().setLevel(logging.WARNING)
        app_logger.setLevel(logging.DEBUG)
        app_logger.propagate = False

        formatter = logging.Formatter(fmt=_FORMAT, datefmt=_DATE_FMT)

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)

        log_path = Path(log_file)
        log_path.parent.mkdir(exist_ok=True)
        file_handler = logging.FileHandler(
            filename=log_path,
            mode="a",
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)

        app_logger.addHandler(console_handler)
        app_logger.addHandler(file_handler)

    @classmethod
    def get(cls, name: str) -> logging.Logger:
        """Returns a logger under the configured app root namespace."""
        if not cls._configured:
            cls.configure(cls._app_root)
        return logging.getLogger(f"{cls._app_root}.{name}")
