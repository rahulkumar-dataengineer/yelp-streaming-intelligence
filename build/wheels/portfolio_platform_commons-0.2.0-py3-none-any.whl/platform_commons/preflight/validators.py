"""Parameterized connectivity validators for shared infrastructure services.

Only tests services provided by this library:
  - Docker daemon
  - Kafka/Redpanda broker
  - Schema Registry
  - PostgreSQL (Hive Metastore backing store)
  - Hive Metastore (Thrift)

Projects add their own validators for project-specific services
(BigQuery, Qdrant, Gemini, etc.).
"""

import subprocess
from typing import Callable


def _pass(service: str, detail: str = "") -> None:
    msg = f"----- PASS ----- [{service}]"
    if detail:
        msg += f" {detail}"
    print(msg)


def _fail(service: str, error: str) -> None:
    print(f"xxxxx FAIL xxxxx [{service}] : {error}")


def test_docker() -> bool:
    """Verify Docker daemon is running."""
    print("\nTesting Docker...")
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            _fail("Docker", "Docker daemon is not running. Start Docker Desktop.")
            return False
        _pass("Docker", "daemon is running")
        return True
    except FileNotFoundError:
        _fail("Docker", "Docker CLI not found. Install Docker Desktop.")
        return False
    except subprocess.TimeoutExpired:
        _fail("Docker", "Docker command timed out")
        return False


def test_kafka(bootstrap_servers: str) -> bool:
    """Verify Kafka broker is reachable and list topics."""
    print("\nTesting Kafka/Redpanda broker...")
    try:
        from confluent_kafka.admin import AdminClient

        admin = AdminClient({"bootstrap.servers": bootstrap_servers})
        metadata = admin.list_topics(timeout=5)
        topics = set(metadata.topics.keys())

        print(f"   Broker: {bootstrap_servers}")
        print(f"   Topics: {sorted(topics) if topics else '(none yet)'}")
        _pass("Kafka/Redpanda")
        return True
    except Exception as exc:
        _fail("Kafka/Redpanda", f"Cannot reach broker at {bootstrap_servers} — {exc}")
        return False


def test_schema_registry(registry_url: str) -> bool:
    """Verify schema registry is reachable."""
    print("\nTesting Schema Registry...")
    try:
        import requests

        url = f"{registry_url}/subjects"
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        subjects = resp.json()

        types_resp = requests.get(f"{registry_url}/schemas/types", timeout=5)
        supported_types = types_resp.json() if types_resp.ok else []

        print(f"   URL:      {registry_url}")
        print(f"   Types:    {supported_types}")
        print(f"   Subjects: {subjects if subjects else '(none yet — run producer)'}")
        _pass("Schema Registry")
        return True
    except Exception as exc:
        _fail("Schema Registry", f"Cannot reach registry at {registry_url} — {exc}")
        return False


def test_postgresql(
    container_name: str = "metastore-db",
    user: str = "hive",
    database: str = "hive_metastore",
) -> bool:
    """Verify PostgreSQL is reachable via Docker."""
    print("\nTesting PostgreSQL (metastore backing store)...")
    try:
        result = subprocess.run(
            ["docker", "exec", container_name, "pg_isready", "-U", user, "-d", database],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            _fail("PostgreSQL", f"Not ready — {result.stderr.strip()}")
            return False

        print(f"   Container: {container_name}")
        print(f"   Database:  {database}")
        print(f"   Status:    accepting connections")
        _pass("PostgreSQL")
        return True
    except FileNotFoundError:
        _fail("PostgreSQL", "Docker CLI not found")
        return False
    except subprocess.TimeoutExpired:
        _fail("PostgreSQL", "Health check timed out")
        return False
    except Exception as exc:
        _fail("PostgreSQL", str(exc))
        return False


def test_hive_metastore(
    metastore_uri: str,
    warehouse_dir: str,
    databases: list[str] | None = None,
) -> bool:
    """Verify Hive Metastore Thrift service is reachable."""
    print("\nTesting Hive Metastore...")
    try:
        from pyspark.sql import SparkSession

        spark = (
            SparkSession.builder
            .appName("MetastoreValidation")
            .master("local[1]")
            .config("spark.sql.catalogImplementation", "hive")
            .config("hive.metastore.uris", metastore_uri)
            .config("spark.sql.warehouse.dir", warehouse_dir)
            .config("spark.driver.memory", "512m")
            .config("spark.ui.enabled", "false")
            .enableHiveSupport()
            .getOrCreate()
        )
        spark.sparkContext.setLogLevel("ERROR")

        all_databases = [row.namespace for row in spark.sql("SHOW DATABASES").collect()]
        tables: list[str] = []
        check_dbs = databases or all_databases
        for db in check_dbs:
            if db in all_databases:
                db_tables = [row.tableName for row in spark.sql(f"SHOW TABLES IN {db}").collect()]
                tables.extend([f"{db}.{t}" for t in db_tables])

        spark.stop()

        print(f"   URI:       {metastore_uri}")
        print(f"   Databases: {sorted(all_databases)}")
        print(f"   Tables:    {sorted(tables) if tables else '(none yet)'}")
        _pass("Hive Metastore")
        return True
    except Exception as exc:
        _fail("Hive Metastore", f"Cannot reach metastore at {metastore_uri} — {exc}")
        return False


def run_all(tests: list[tuple[str, Callable[[], bool]]]) -> bool:
    """Runs a list of (name, test_fn) pairs and prints summary.

    Args:
        tests: List of (service_name, test_function) tuples.

    Returns:
        True if all tests passed.
    """
    results: dict[str, bool] = {}
    for name, test_fn in tests:
        results[name] = test_fn()

    print("\n" + "=" * 60)
    print("  SUMMARY")
    print("=" * 60)

    all_passed = True
    for service, passed in results.items():
        if passed:
            _pass(service)
        else:
            _fail(service, "see details above")
            all_passed = False

    if all_passed:
        print("\nAll services connected.")
    else:
        print("\nFix the FAIL(s) above before proceeding.")

    print("=" * 60)
    return all_passed
